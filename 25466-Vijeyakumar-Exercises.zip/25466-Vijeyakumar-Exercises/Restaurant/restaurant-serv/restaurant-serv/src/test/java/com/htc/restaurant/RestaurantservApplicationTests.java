package com.htc.restaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantservApplicationTests {

	@Test
	void contextLoads() {
	}

}
