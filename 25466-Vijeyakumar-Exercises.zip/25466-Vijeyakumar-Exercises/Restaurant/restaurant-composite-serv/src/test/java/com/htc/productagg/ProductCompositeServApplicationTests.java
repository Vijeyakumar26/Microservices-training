package com.htc.productagg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductCompositeServApplicationTests {

	@Test
	void contextLoads() {
	}

}
