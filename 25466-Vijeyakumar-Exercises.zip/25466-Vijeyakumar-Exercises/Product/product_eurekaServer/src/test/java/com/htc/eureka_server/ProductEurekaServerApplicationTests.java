package com.htc.eureka_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
