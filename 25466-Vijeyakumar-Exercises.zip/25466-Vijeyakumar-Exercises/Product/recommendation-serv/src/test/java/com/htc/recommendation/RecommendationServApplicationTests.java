package com.htc.recommendation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecommendationServApplicationTests {

	@Test
	void contextLoads() {
	}

}
