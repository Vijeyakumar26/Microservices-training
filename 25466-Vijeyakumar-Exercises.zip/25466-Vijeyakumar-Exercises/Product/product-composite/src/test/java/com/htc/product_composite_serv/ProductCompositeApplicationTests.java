package com.htc.product_composite_serv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductCompositeApplicationTests {

	@Test
	void contextLoads() {
	}

}
